package Factory;

public interface Product {
    void printProductInfo();
}
